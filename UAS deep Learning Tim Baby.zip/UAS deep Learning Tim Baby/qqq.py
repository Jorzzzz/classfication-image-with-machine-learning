
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

import tensorflow as tf
from tensorflow.keras import models, layers
import matplotlib.pyplot as plt
from PIL import Image
import numpy as np
from tensorflow.keras.layers.experimental import preprocessing
from tensorflow.keras.preprocessing.image import load_img
import matplotlib.pyplot as plt
from tensorflow import keras
from tensorflow.keras import preprocessing

from keras.preprocessing import image
import matplotlib.pyplot as plt
import base64



BATCH_SIZE = 62
IMAGE_SIZE = 256
EPOCHS=62
CHANNELS=3

model = keras.models.load_model('model.h5')

dataset = tf.keras.preprocessing.image_dataset_from_directory(
    "dataset/train"
)

class_names = dataset.class_names

def clasify(fotonya):
	img = image.load_img(fotonya, target_size=(224, 224))
	imgplot = plt.imshow(img)
	x = image.img_to_array(img)
	x = np.expand_dims(x, axis=0)

	images = np.vstack([x])
	classes = model.predict(images, batch_size=BATCH_SIZE)
	class_index = np.argmax(classes)
	class_indeks = int(class_index)
	# pred = class_names[class_indeks]
	# print(pred)
	with open(fotonya, "rb") as image_file:
		encoded_string = base64.b64encode(image_file.read())
		imgx = str(encoded_string).replace("b'", "")
		kutip = str(imgx).replace("'", "")
		

	try:
		pred = class_names[class_indeks]
		jsonDATA = {"msg": pred,"img": str(kutip)}
		return jsonDATA
	except:
		jsonDATA = {"msg": "Dataset error"}
		return jsonDATA
